﻿using UnityEngine;
using System.Collections;

public class PumpkinTosser : MonoBehaviour 
{
    public Rigidbody pumpkin;
    public float initialSpeed = 1500f;
    private float moveSpeed = 5f;
    void Start ()
    {
    }
    void Update()
    {
        float deltaX = Input.GetAxis("Horiziontal") * Time.deltaTime * moveSpeed;
        float deltaY = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;
        transform.Translate(deltaX, deltaY, 0); //deltaZ = 0
        if (Input.GetButtonUp("Fire1"))
        {
            Rigidbody pumpkinInstance = Instantiate(pumpkin, transform.position, transform.rotation) as Rigidbody;
            Vector3 fwd = transform.TransformDirection(Vector3.forward);
            pumpkinInstance.AddForce(fwd * initialSpeed);
        }
    }
}
